gg up(gg n, gg m) { return n >= 0 ? (n + m - 1) / m : n / m; }
gg down(gg n, gg m) { return n >= 0 ? n / m : (n - m + 1) / m; }
